$(document).ready(function(){

	cufon_init();
	
	load_init();
	
	package_init();
	
	form_init();
	
	letterblocks_init();
	
	testimonials_init();
	
	if (!('placeholder' in document.createElement('input')))
	{
		$('input[placeholder!=""], textarea[placeholder!=""]').each(function(){
			inputPlaceholder(this);
		});
	}
	
	$('a[href^=#]').click(function(){
		var id=$(this).attr('href');
		if($(id+'.to-expand').length && id != '#')
		{
			$(this).slideUp(300);
			$(id).slideDown(300);
			return false;
		}
	});
});

/***********************/

function inputPlaceholder (input, color) {

	if (!input) return null;

	// Do nothing if placeholder supported by the browser (Webkit, Firefox 3.7)
	//if (input.placeholder && 'placeholder' in document.createElement(input.tagName)) return input;

	color = color || '#AAA';
	var default_color = input.style.color;
	var placeholder = input.getAttribute('placeholder');

	if (input.value === '' || input.value == placeholder) {
		input.value = placeholder;
		input.style.color = color;
		input.setAttribute('data-placeholder-visible', 'true');
	}

	var add_event = /*@cc_on'attachEvent'||@*/'addEventListener';

	input[add_event](/*@cc_on'on'+@*/'focus', function(){
	 input.style.color = default_color;
	 if (input.getAttribute('data-placeholder-visible')) {
		 input.setAttribute('data-placeholder-visible', '');
		 input.value = '';
	 }
	}, false);

	input[add_event](/*@cc_on'on'+@*/'blur', function(){
		if (input.value === '') {
			input.setAttribute('data-placeholder-visible', 'true');
			input.value = placeholder;
			input.style.color = color;
		} else {
			input.style.color = default_color;
			input.setAttribute('data-placeholder-visible', '');
		}
	}, false);

	input.form && input.form[add_event](/*@cc_on'on'+@*/'submit', function(){
		if (input.getAttribute('data-placeholder-visible')) {
			input.value = '';
		}
	}, false);

	return input;
}

/***********************/

function load_init()
{
	$('.circle-wrapper, .circle-shadow').fadeTo(0,0);
	$('.main-header, .sale-label, .main-image, .girl, .packageline, .footerline').hide();

	setTimeout(function(){
		
		$('.circle-wrapper').fadeTo(1000,1);
		if($('.circle').width() == $('.circle').height())
		{
			$('.circle').rotate({animateTo: 720, duration: 1000});
		}
	}, 500);

	setTimeout(function(){
		$('.main-header, .sale-label').fadeTo(600,1);
		setTimeout(function(){
			$('.main-image').fadeTo(600,1);
			setTimeout(function(){
				$('.packageline').slideDown(300);
				setTimeout(function(){
					$('.circle-shadow').fadeTo(300,1);
					$('.footerline').slideDown(300);
				},300);
			},300);
		},150);
	},1500);

	setTimeout(function(){
		var url=$('.girl').css('background-image');
		if(url == 'none')
		{
			$('.girl').slideDown(500, 'easeOutExpo');
		}
		else
		{
			$img=$('<img />');
			$img.load(function(){
				$('.girl').slideDown(500, 'easeOutExpo');
			});
			$img.attr('src',url.replace('url(','').replace(')','').replace(/"/g,'').replace(/'/g,''));
		}

	},2300);

}

/***********************/

function cufon_init()
{
	Cufon.replace('h1', { textShadow: '2px 3px rgba(255,255,255,0.8)'});
	Cufon.replace('h2, h3, h4, h5, h6, .packages .name', { textShadow: '0 1px #ffffff'});
	Cufon.replace('.packages .button', { textShadow: '0 -1px rgba(0,0,0,0.5)'});
	Cufon.replace('.letter-block', { textShadow: '0 -1px rgba(0,0,0,0.2)'});
	Cufon.replace('.sale-label', { textShadow: '0px 1px rgba(0,0,0,0.3)'});
	Cufon.replace('.packages .price');
}

/***********************/

var packageTimeout;
function package_init()
{
	$('.packages').before('<div id="medicine-pic"><div class="pic"></div><div class="price-label"></div></div>');
	var $act=$('.packages > li.active:first');
	if($act.length)
	{
		$('#medicine-pic > .pic').html($act.children('.pic').html());
		$('#medicine-pic > .price-label').html($act.children('.price').text());
		Cufon.refresh('.price-label');
	}
	
	$('.packages > li').mouseenter(function(){
		if(!$(this).hasClass('active'))
		{
			var $act=$(this);
			$(this).parent().children('li').removeClass('active');
			$(this).addClass('active');
			
			$('#medicine-pic > .pic').stop(true).animate({left: '-240px', opacity: 0}, 400, 'easeInExpo');
			clearTimeout(packageTimeout);
			packageTimeout=setTimeout(function(){
				$('#medicine-pic > .price-label').stop(true).animate({marginLeft: '-140px', opacity: 0}, 400, 'easeInExpo', function(){
					if($act.children('.pic').length)
					{
						$('#medicine-pic > .pic').html($act.children('.pic').html());
						$('#medicine-pic > .price-label').html($act.children('.price').text());
						Cufon.refresh('.price-label');
						
						$('#medicine-pic > .pic').stop(true).css('left','140px').animate({left: '0px', opacity: 1}, 400, 'easeOutExpo');
						packageTimeout=setTimeout(function(){
							$('#medicine-pic > .price-label').stop(true).css('margin-left','140px').animate({marginLeft: '0px', opacity: 1}, 400, 'easeOutExpo');
						},50);
					}
				});
			}, 150);
		}
	});
}

/***********************/

function form_init()
{
	$('#form-close').click(function(){
		form_close();
		return false;
	});
	
	$('#form-link').click(function(){
		if($('#form-pane').length)
		{
			var pos=$(this).position();
			var w=$('#form-pane').outerWidth();
			var h=$('#form-pane').outerHeight();
			$('#form-pane').css('min-height',$('#form-pane').height()+'px');
			$('body').append('<div id="fader"></div>');
			$('#fader').click(form_close);
			$('#fader').css('display','block').fadeTo(300,0.6);
			$('#form-pane').css('left',Math.round((pos.left-w/2+$(this).width()/2))+'px').css('top',(pos.top-h-20)+'px').fadeTo(300,1);
			return false;
		}
	});
	
  var options = {
		data: { site: 1 },
		success: form_success,
		dataType: 'json',
		beforeSubmit: form_before
	}; 	
	
	$("#form").validate({
		submitHandler: function(form) {
			$(form).ajaxSubmit(options);
		},
		errorPlacement: function(error, element) {
		},
		wrapper: 'div'
	});
}

function form_close()
{
	$('#fader, #form-pane').fadeTo(300,0,function(){
		$('#fader').remove();
		$('#form-pane').hide();
	});
}

function form_before()
{
	var $obj=$('#form');
	$obj.fadeTo(300,0.5);
	$obj.before('<div id="form-blocker" style="position:absolute;width:'+$obj.outerWidth()+'px;height:'+$obj.outerHeight()+'px;z-index:9999;background:url(img/ajax-loading.gif) no-repeat center center"></div>');
}

function form_success(obj)
{
	$('#form-blocker').remove();
	if(obj.error == 0)
	{
		$('#form').fadeOut(300,function(){
			$('#form').remove();
			$('#form-success').fadeIn(200);
		});
	}
	else
	{
		$('#form').fadeOut(300,function(){
			$('#form').remove();
			$('#form-error').fadeIn(200);
		});		
	}
}

function testimonials_init()
{
	if($('#testimonials .item').length > 1)
	{
		$('#testimonials .item .photo img').each(function(){
			$(this).parent().css('background-image','url('+$(this).attr('src')+')');
			$(this).remove();
		});
		$('#testimonials .item:gt(0)').css('opacity',0);
		
		$('#testimonials-control-left').mouseenter(function(){
			$(this).stop(true).css('background-position','-95px 23px').animate({backgroundPosition: '-99px 23px'}, 200);
		}).mousedown(function(){
			$(this).stop(true).css('background-position','-100px 24px');
		}).mouseup(function(){
			$(this).stop(true).css('background-position','-99px 23px');
		}).mouseleave(function(){
			$(this).stop(true).css('background-position','5px 23px');
		}).click(function(){
			$('#testimonials .item:first').stop(true,true).animate({marginLeft: '150px', opacity: 0}, 200, function(){
				$(this).css('margin-left',0);
				$('#testimonials .item:last').detach().prependTo('#testimonials');
				$('#testimonials .item:first').css('margin-left','-150px').animate({marginLeft: 0, opacity: 1}, 700, 'easeOutExpo');
			});
			
			return false;
		});
		
		$('#testimonials-control-right').mouseenter(function(){
			$(this).stop(true).css('background-position','-256px 23px').animate({backgroundPosition: '-252px 23px'}, 200);
		}).mousedown(function(){
			$(this).stop(true).css('background-position','-251px 24px');
		}).mouseup(function(){
			$(this).stop(true).css('background-position','-252px 23px');
		}).mouseleave(function(){
			$(this).stop(true).css('background-position','-356px 23px');
		}).click(function(){
			$('#testimonials .item:first').stop(true,true).animate({marginLeft: '-150px', opacity: 0}, 200, function(){
				var $obj=$(this).detach();
				$obj.css('margin-left',0).appendTo('#testimonials');
				$('#testimonials .item:first').css('margin-left','150px').animate({marginLeft: 0, opacity: 1}, 700, 'easeOutExpo');
			});
			return false;
		});
	}
	else
	{
		$('#testimonials-control-left, #testimonials-control-right').css('visibility','hidden');
	}
}

function letterblocks_init()
{
	$('.letter-block').addClass('js').wrapInner('<div class="text"/>').prepend('<div class="bg"/>');

	$('.one-third').mouseenter(function(){
		$(this).children('.letter-block').children('.bg').rotate({angle:0});
		$(this).children('.letter-block').children('.bg').rotate({animateTo: 360, duration: 4000});
	});
}