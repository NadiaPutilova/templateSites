$(window).load(function() {
	$('#slider').nivoSlider({
		effect: 'random',
		slices: 15,
		animSpeed: 500,
		pauseTime: 5000,
		startSlide: 0
	});
});