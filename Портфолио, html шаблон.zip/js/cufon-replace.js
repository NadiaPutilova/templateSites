Cufon.replace('h1', { fontFamily: 'AG Foreigner Light-Plain', color: '-linear-gradient(#aeaeae, #8c8c8c)' });
Cufon.replace('h1 span', { fontFamily: 'AG Foreigner Light-Plain', color: '-linear-gradient(#dcdcdc, #b2b2b2)' });
Cufon.replace('h2', { fontFamily: 'AG Foreigner Light-Plain' });
Cufon.replace('nav ul li', { fontFamily: 'Myriad Pro Regular', hover:true });