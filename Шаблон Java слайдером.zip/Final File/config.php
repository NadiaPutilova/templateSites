<?php
    $email_to =   'email@domain.com'; //the address to which the email will be sent
?>