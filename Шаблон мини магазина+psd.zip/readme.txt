------------------
DelliStore
A CSS+(X)HTML-based template (with PSD-sources).
Designed by Wendell Fernandes and Dellustrations (http://www.dellustrations.com)
This template, designed by the design agency Dellustrations especially for Smashing Magazine and its readers, is a full px-based, cross-browser-compliant (X)HTML/CSS-template (IE 6, IE 7, Firefox, Safari, Google Chrome). It consists of 4 custom pages; the PSD-source is included in the release package. You may modify this template for a e-commerce web site, restaurant, pool and spa web-sites and other caters, ventures and facilities.
------------------

Dear friends,

thank you for downloading this file.

You can freely use this template for both your private and commercial projects, including software, online services, templates and themes.