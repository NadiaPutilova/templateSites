Cufon.replace('h2, h3, h4, .button, .support-phone', { fontFamily: 'Vegur', hover:true });
Cufon.replace('.menu > li > a', { fontFamily: 'Vegur', hover:true });
Cufon.replace('.footer-text', { fontFamily: 'Vegur', textShadow:'0 0 #fff', hover:true });
