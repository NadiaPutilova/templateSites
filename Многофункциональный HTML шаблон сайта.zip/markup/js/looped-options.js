$(function(){
		$('#steps-slider').loopedSlider({
		});
		$('#intro-slider').loopedSlider({
			autoStart:5000
		});
	});