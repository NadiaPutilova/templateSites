(function($) {
        $(function() {

			$(function() {
			$('.large').fadeOut();
			$(window).load(function() {
			$('.loader').hide();
			$('.large').fadeIn();
			}); });
          });
    })(jQuery);
 
