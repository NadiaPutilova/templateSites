------------------
CSS Templates
Designed by Templateworld (http://www.templateworld.com)
------------------

Dear Friends,

Thank you for downloading this file.

These templates have been brought to you by SmashingMagazine.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes. 
Please link to the article in which this freebie was released if you like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
